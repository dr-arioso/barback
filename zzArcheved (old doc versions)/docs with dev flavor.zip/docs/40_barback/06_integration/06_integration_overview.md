
# Barback Integration Overview

Barback integrates BoozeDex (taxonomy + tags), StashKit (framework), and the
domain-specific Barback StashPack (skills, resolvers, pipelines, classification).

This subsystem describes how Barback ties the pieces together into a unified,
fully automated bottle identification and inventory workflow.
