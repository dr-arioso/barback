
# Module Map

```
stashkit/
  core/
  dex/
  skills/
  resolvers/
  stashes/
  config/
  errors/
  utils/
  boosters/
```

Each module cleanly encapsulates a subsystem, enabling BoosterPacks to extend functionality without modifying the core.
