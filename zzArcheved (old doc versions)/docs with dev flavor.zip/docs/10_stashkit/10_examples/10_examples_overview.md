
# Examples Subsystem Overview

The Examples subsystem provides practical, end-to-end demonstrations of how
StashKit components—Skills, Resolvers, Pipelines, Stashes, and Config—work
together in real usage scenarios. These examples serve as reference patterns
for developers creating their own StashKit-based applications.
