
# Template: Skill Definition

Booster Packs can provide default Skill configurations:

```
id: upc_skill
type: skill

config:
  enabled: true
  api_timeout_ms: 1500
  providers:
    - open_product_data
    - open_food_facts
```

Booster Packs may also include Python implementations if needed.
