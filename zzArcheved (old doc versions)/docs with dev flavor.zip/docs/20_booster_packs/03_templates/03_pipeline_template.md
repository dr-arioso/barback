
# Template: Pipeline Definition

```
id: bottle_pipeline
type: pipeline

resolvers:
  - bottle_resolver

persistence:
  write_to_stash: true
```

Most applications will override certain details in project-level config.
