
# Mixers Taxonomy

```
mixers:
  soda:
    tonic:
    club_soda:
    ginger_ale:
  juice:
    orange:
    lime:
    lemon:
    pineapple:
    cranberry:
  syrup:
    simple:
    honey:
    maple:
    grenadine:
  bitters:
    aromatic:
    orange:
    chocolate:
  cream:
    heavy_cream:
    coconut_cream:
```

Bitters are located here, not under liqueurs, because they are typically low-volume modifiers.
