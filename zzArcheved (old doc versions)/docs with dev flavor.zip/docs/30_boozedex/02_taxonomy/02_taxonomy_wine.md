
# Wine Taxonomy

```
wine:
  red:
    cabernet_sauvignon:
    merlot:
    pinot_noir:
    syrah:

  white:
    chardonnay:
    sauvignon_blanc:
    riesling:

  rosé:

  sparkling:
    champagne:
    prosecco:
    cava:
    pet_nat:

  fortified:
    sherry:
    port:
    madeira:

  aromatized:
    vermouth:
      sweet:
      dry:
      blanc:
```

Notes:
- Vermouth is wine, not a spirit → correctly housed under aromatized wines.
