
# Taxonomy Example Usage

### Example: Cointreau  
Path:
```
spirits.liqueurs.fruit.orange.triple_sec
```

### Example: Maker’s Mark  
```
spirits.whiskey.bourbon
```

### Example: Aperol  
```
spirits.liqueurs.herbal.aperitivo.aperol_style
```

### Example: Lagunitas IPA  
```
beer.ale.ipa
```

### Example: Cocchi Vermouth di Torino  
```
wine.aromatized.vermouth.sweet
```

These examples reinforce both correctness and intuitive classification.
