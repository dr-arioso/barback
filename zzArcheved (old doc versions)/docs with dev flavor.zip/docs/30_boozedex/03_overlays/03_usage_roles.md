
# Usage Roles Overlay

Usage roles describe when or how a beverage is typically consumed.

```
usage_roles:
  aperitif:
  digestif:
  dessert:
  sessionable:
  celebratory:
  winter_warmer:
  summer_refreshing:
```

Examples:
- Aperol → aperitif  
- Fernet → digestif  
- Champagne → celebratory  
