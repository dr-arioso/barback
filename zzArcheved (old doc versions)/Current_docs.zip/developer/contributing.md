# Contributing

Guidelines:
- Use composition, not inheritance, for skills
- Keep StashKit domain-neutral
- Keep Barback domain-specific
- Add tests for every skill and resolver
- Document new features within docs/

