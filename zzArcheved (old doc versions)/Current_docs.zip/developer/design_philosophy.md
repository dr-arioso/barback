# Design Philosophy

Principles:
- Explicit > implicit
- Composition > inheritance
- Domain boundaries must remain clear
- Skills return dicts; resolvers validate
- Applications define skill ordering
- StashKit remains product-domain-neutral

