# Versioning

StashKit uses semantic versioning:
- MAJOR: Breaking API changes
- MINOR: New features, no breaking changes
- PATCH: Bug fixes

Barback may version independently because it is domain-specific.

