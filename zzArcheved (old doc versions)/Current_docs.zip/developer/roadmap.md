# Roadmap

Future development:
- Vision model integration
- OCR infrastructure
- Additional public metadata providers
- 3D bottle layout planner (Barback)
- Plugin system for third-party product resolvers
- Cloud datastore support

