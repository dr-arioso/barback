
# Origin & Context StashTags

```
origin:
  american
  french
  italian
  mexican
  japanese
  scottish
  caribbean
  german

context:
  holiday
  summer
  winter
  classic
  modern
```

Notes:
- Origin is broad; geographic specificity should not go below country-level.
- Context tags are optional, useful for UI generation.
