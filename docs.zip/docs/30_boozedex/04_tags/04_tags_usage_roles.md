
# Usage Roles StashTags

Usage describes when or how a beverage is typically consumed.

```
usage:
  aperitif
  digestif
  celebratory
  dessert
  sessionable
  winter_warmer
  summer_refreshing
```

Examples:
- Fernet → digestif  
- Champagne → celebratory  
