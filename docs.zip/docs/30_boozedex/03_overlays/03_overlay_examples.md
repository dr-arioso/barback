
# Overlay Examples

### Aperol
- Tags:
  - aperitif
  - citrus
  - bitter
  - modifier

### Maker’s Mark
- Tags:
  - woody
  - sweet
  - base_spirit (in cocktails)

### Campari
- Tags:
  - bitter
  - citrus
  - aperitif
  - modifier

### Fernet-Branca
- Tags:
  - bitter
  - herbal
  - digestif
```

These overlays allow BoozeDex to support polyhierarchy without complicating the core taxonomy.
