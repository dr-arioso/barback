
# Beer & Cider Taxonomy

```
beer:
  lager:
    pilsner:
    helles:
    amber_lager:
  ale:
    ipa:
    pale_ale:
    stout:
    porter:
    wheat:
  sour:
    gose:
    lambic:

cider:
  dry:
  semi_dry:
  sweet:
  flavored:
```
