
# Barback Developer Reference — Overview

This section provides authoritative, technical documentation for developers
extending, embedding, or contributing to Barback.  
It supplements subsystem documentation with a consolidated API reference,
architectural diagrams, coding guidelines, and extension recipes.
